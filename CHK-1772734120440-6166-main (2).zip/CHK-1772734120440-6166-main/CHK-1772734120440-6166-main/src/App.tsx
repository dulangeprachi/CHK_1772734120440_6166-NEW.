import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import WelcomeScreen from "./pages/WelcomeScreen";
import ScannerScreen from "./pages/ScannerScreen";
import MedicineDetailsScreen from "./pages/MedicineDetailsScreen";
import LanguageScreen from "./pages/LanguageScreen";
import VoiceScreen from "./pages/VoiceScreen";
import ReminderScreen from "./pages/ReminderScreen";
import BottomNav from "./components/BottomNav";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<WelcomeScreen />} />
          <Route path="/scan" element={<ScannerScreen />} />
          <Route path="/details" element={<MedicineDetailsScreen />} />
          <Route path="/language" element={<LanguageScreen />} />
          <Route path="/voice" element={<VoiceScreen />} />
          <Route path="/reminders" element={<ReminderScreen />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <BottomNav />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
